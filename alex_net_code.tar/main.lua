--
--  Copyright (c) 2014, Facebook, Inc.
--  All rights reserved.
--
--  This source code is licensed under the BSD-style license found in the
--  LICENSE file in the root directory of this source tree. An additional grant
--  of patent rights can be found in the PATENTS file in the same directory.
--
require 'torch'
require 'cutorch'
require 'paths'
require 'xlua'
require 'optim'
require 'nn'

torch.setdefaulttensortype('torch.FloatTensor')

local opts = paths.dofile('opts.lua')

opt = opts.parse(arg)

nClasses = opt.nClasses

paths.dofile('util.lua')
paths.dofile('model.lua')
opt.imageSize = model.imageSize or opt.imageSize
opt.imageCrop = model.imageCrop or opt.imageCrop

print(opt)

cutorch.setDevice(opt.GPU) -- by default, use GPU 1
torch.manualSeed(opt.manualSeed)

print('Saving everything to: ' .. opt.save)
os.execute('mkdir -p ' .. opt.save)

paths.dofile('data.lua')
paths.dofile('train.lua')
paths.dofile('test.lua')

epoch = opt.epochNumber


--model:get(1):get(1).accGradParameters = function() end
--model:get(1):get(2).accGradParameters = function() end
--model:get(1):get(3).accGradParameters = function() end
--model:get(1):get(4).accGradParameters = function() end
--model:get(1):get(5).accGradParameters = function() end
--model:get(1):get(6).accGradParameters = function() end
--model:get(1):get(7).accGradParameters = function() end
--model:get(1):get(8).accGradParameters = function() end
--model:get(1):get(9).accGradParameters = function() end
--model:get(1):get(10).accGradParameters = function() end
--model:get(1):get(11).accGradParameters = function() end
--model:get(1):get(12).accGradParameters = function() end
--model:get(1):get(13).accGradParameters = function() end


for i=1,opt.nEpochs do
   train()
   test()
   epoch = epoch + 1
end
